Mê cung Khốc liệt
=================

Bản dịch tiếng Việt để thi Phần mềm Sáng tạo trong Hội thi Tin học trẻ năm 2018.

.. image:: https://raw.githubusercontent.com/McSinyx/brutalmaze/master/screenshot.png
   :target: https://McSinyx.github.io/brutalmaze/

Bản thuyết minh tiếng Việt được `soạn thảo trên LaTeX
<https://github.com/McSinyx/brutalmaze/blob/vietnamese-translation/README.tex>`_ và
dịch sang `định dạng PDF
<https://raw.githubusercontent.com/McSinyx/brutalmaze/vietnamese-translation/README.pdf>`_.


