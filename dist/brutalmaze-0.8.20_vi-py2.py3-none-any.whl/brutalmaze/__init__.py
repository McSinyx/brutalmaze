"""Brutal Maze is a minimalist third-person shooter with fast-paced action"""
